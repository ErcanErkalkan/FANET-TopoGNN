# publication_neural_extension report

- Seeds: 2
- Forecast horizon steps: 6
- Best model by MAE: Kinetic-TopoGuard
- Best model by lead: FANET-TopoGNN, FANET-TopoGNN (concat), GCN, TGN (w=5), T-GCN (w=5), PI+MLP
- Wall-clock runtime: 2155.7 s
- CUDA available during run: false

## Accuracy
- Best MAE model: Kinetic-TopoGuard
- MAE mean: 0.1217
- R2 mean: 0.3176

## Early warning
- Best median lead model: FANET-TopoGNN, FANET-TopoGNN (concat), GCN, TGN (w=5), T-GCN (w=5), PI+MLP
- Median lead mean: 600.00 ms

## Risk detection
                 Model  Risk_F1_mean  Risk_Recall_mean  Risk_Precision_mean
             TGN (w=5)      0.212396          1.000000             0.119615
                   GCN      0.251751          0.961656             0.144835
                PI+MLP      0.275594          0.984902             0.164216
           T-GCN (w=5)      0.274545          0.973144             0.161278
     Kinetic-TopoGuard      0.648957          0.846431             0.531441
         FANET-TopoGNN      0.270826          0.995887             0.159246
           STGCN (w=5)      0.327393          0.936019             0.201137
FANET-TopoGNN (concat)      0.307050          0.961509             0.182851
             GraphSAGE      0.317255          0.947396             0.190549
                   GAT      0.409196          0.870483             0.267527

## Network impact
                 Model  Connectivity ratio_mean  Reachability-delivery proxy (%)_mean  Proxy delay (ms)_mean  Proactive reroute (%)_mean  DTN buffered (%)_mean  Relay actions_mean
                   GAT                 0.933264                             99.799782              18.163523                   13.052394               0.353514              3713.5
     Kinetic-TopoGuard                 0.930347                             99.781903              18.301729                    2.466947               0.354104              2270.5
             GraphSAGE                 0.927083                             99.799331              18.154508                   19.044900               0.378374              5222.0
FANET-TopoGNN (concat)                 0.926736                             99.797341              18.145455                   19.372388               0.377721              5440.5
                   GCN                 0.926736                             99.796331              18.095967                   28.865734               0.378514              6682.0
         FANET-TopoGNN                 0.925000                             99.794372              18.128519                   25.508706               0.384608              6529.0
