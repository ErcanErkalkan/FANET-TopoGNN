# Supplementary Material S1: detailed table index

The manuscript keeps eight decision-critical tables in the main text. Detailed LaTeX
tables and machine-readable sources remain in S1 under `tables/detailed/` and `outputs/`.
These include the earlier 20-seed benchmark, complete five-seed neural model
family, feature attribution, forecast-horizon sweep, event-protocol sensitivity, all four
external-evidence layers, operating policies, and the one-step packet-load sweep.

The five-seed PyTorch extension is descriptive model-family context, not confirmatory
evidence. `configs/eaai_neural_20seed_extension.json` and
`scripts/run_neural_20seed_extension.py` prepare a domain-separated 20-new-seed extension.
The launcher refuses surrogate execution. Its status is `prepared_not_executed`; S1 does
not contain or imply results for that pending protocol.
